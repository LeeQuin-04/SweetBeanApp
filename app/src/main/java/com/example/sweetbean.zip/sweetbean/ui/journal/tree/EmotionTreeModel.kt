package com.example.sweetbean.ui.journal.tree

import com.example.sweetbean.data.journal.Emotion
import com.example.sweetbean.data.journal.Journal
import java.util.Calendar
import kotlin.math.abs

enum class MonthStatus { FUTURE, EMPTY, IN_PROGRESS, DONE }

data class MonthSummary(
    val month: Int,                    // 1..12
    val status: MonthStatus,
    val counts: Map<Emotion, Int>,     // chỉ gồm cảm xúc có xuất hiện
    val dominant: List<Emotion>        // 1 cảm xúc chủ đạo, hoặc nhiều nếu hòa nhau
) {
    val total: Int get() = counts.values.sum()
}

object EmotionTreeCalculator {

    fun summarize(
        year: Int,
        journals: List<Journal>,
        now: Calendar = Calendar.getInstance()
    ): List<MonthSummary> {
        val currentYear = now.get(Calendar.YEAR)
        val currentMonth = now.get(Calendar.MONTH) + 1

        val byMonth = journals.groupBy {
            Calendar.getInstance().apply { timeInMillis = it.dateMillis }.get(Calendar.MONTH) + 1
        }

        return (1..12).map { month ->
            val list = byMonth[month].orEmpty()
            val counts = Emotion.entries
                .associateWith { emotion -> list.count { it.emotion == emotion } }
                .filterValues { it > 0 }

            val max = counts.values.maxOrNull()
            // Hòa nhau: giữ cả các cảm xúc bằng số lượng cao nhất, màu sẽ được pha trộn.
            val dominant = if (max == null) emptyList() else counts.filterValues { it == max }.keys.toList()

            val isFuture = year > currentYear || (year == currentYear && month > currentMonth)
            val isCurrent = year == currentYear && month == currentMonth

            val status = when {
                isFuture -> MonthStatus.FUTURE
                list.isEmpty() -> MonthStatus.EMPTY
                isCurrent -> MonthStatus.IN_PROGRESS
                else -> MonthStatus.DONE
            }

            MonthSummary(month, status, counts, dominant)
        }
    }
}

/** Hình học của tán cây, tọa độ chuẩn hoá 0..1 theo ảnh cắt (640x584). */
object TreeGeometry {
    const val IMAGE_RATIO = 1.0959f

    /** Ranh giới giữa 12 dải tháng theo trục ngang; mỗi dải có diện tích tán bằng nhau. */
    private val MONTH_BOUNDS = floatArrayOf(
        0.1836f, 0.2516f, 0.3109f, 0.3671f, 0.4207f, 0.4853f,
        0.5516f, 0.6122f, 0.6704f, 0.7311f, 0.8005f
    )

    private const val TRUNK_CENTER_X = 0.5f
    private const val TRUNK_HALF_W = 0.0905f
    private const val TRUNK_TOP_Y = 0.6143f
    private const val GROUND_Y = 0.8643f

    // Tán cây xấp xỉ một hình elip: chạm ra ngoài tán thì không chọn tháng nào.
    private const val CANOPY_CX = 0.5f
    private const val CANOPY_CY = 0.39f
    private const val CANOPY_RX = 0.50f
    private const val CANOPY_RY = 0.38f

    /** Tháng (1..12) tại điểm (nx, ny); null nếu chạm thân cây, cỏ hoặc ngoài tán. */
    fun monthAt(nx: Float, ny: Float): Int? {
        if (ny >= GROUND_Y) return null
        if (abs(nx - TRUNK_CENTER_X) <= TRUNK_HALF_W && ny >= TRUNK_TOP_Y) return null

        val ex = (nx - CANOPY_CX) / CANOPY_RX
        val ey = (ny - CANOPY_CY) / CANOPY_RY
        if (ex * ex + ey * ey > 1f) return null

        var month = 1
        for (bound in MONTH_BOUNDS) {
            if (nx >= bound) month++ else break
        }
        return month
    }
}